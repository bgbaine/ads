import './App.css'
import { useState } from "react"

function App() {
  const [foto, setFoto] = useState("0");

  const changeFoto = (newFoto) => {
      setFoto(newFoto)
  };
  
  return (
    <>
      <h1>Calçados Avenida</h1>
      <h2>Veja detalhes do tênis: <span className='titulo' ><i>Sketchers</i></span></h2>
      <hr />
      <img src={`${foto}.jpg`} alt="" />
      <div>
        <img className="img-mini" onClick={() => changeFoto("0")} src="./0.jpg" alt="" />
        <img className="img-mini" onClick={() => changeFoto("1")} src="./1.jpg" alt="" />
        <img className="img-mini" onClick={() => changeFoto("2")} src="./2.jpg" alt="" />
      </div>
    </>
  )
}

export default App
