import './App.css'
import { useState } from "react"

const ESTADOS = {
  VERMELHO: 'vermelha',
  AMARELA: 'amarela',
  VERDE: 'verde'
};

const MENSAGENS = {
  [ESTADOS.VERMELHO]: 'Sinal Vermelho: Proibido Passar',
  [ESTADOS.AMARELA]: 'Sinal Amarelo: Prepare-se para Parar',
  [ESTADOS.VERDE]: 'Sinal Verde: Siga em Frente'
};

function App() {
  const [estado, setEstado] = useState("vermelha");

  const changeEstado = () => {
    switch (estado) {
      case ESTADOS.VERMELHO:
        setEstado(ESTADOS.AMARELA);
        break;
      case ESTADOS.AMARELA:
        setEstado(ESTADOS.VERDE);
        break;
      case ESTADOS.VERDE:
        setEstado(ESTADOS.VERMELHO);
        break;
      default:
        break;
    }
  };

  return (
    <>
      <h1 className='titulo'>Escola de Trânsito</h1>
      <h2>Aula sobre Sinaleira</h2>
      <hr />
      <img className='img-sinaleira' onClick={changeEstado} src={`./${estado}.png`} alt="" />
      <h2 className={estado}>{MENSAGENS[estado]}</h2>
      <h3><i>* Clique sobre a sinaleira para trocar de cor</i></h3>
    </>
  )
}

export default App
