import { useState } from 'react'
import './App.css'

function App() {
  const [mesas, setMesas] = useState(10);

  const entradaCliente = () => {
    mesas - 1 < 0 ? null : setMesas(mesas - 1);
  }
  
  const saidaCliente = () => {
    mesas + 1 > 10 ? null : setMesas(mesas + 1);
  }

  return (
    <>
      <h1>Restaurante Avenida</h1>
      <h2>Controle de Mesas</h2>
      <img src="./restaurante.jpg" alt="Restaurante" className="imagem"/>
      <h2>Mesas Disponíveis: 
        <span className='azul'> {mesas} </span>
         - Mesas Ocupadas: 
         <span className="vermelho"> {10 - mesas} </span>
         </h2>
      <button onClick={entradaCliente}>Entrada de Cliente</button>&nbsp;&nbsp;
      <button onClick={saidaCliente}>Saída de Cliente</button>
    </>
  )
}

export default App
