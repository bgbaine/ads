import { useState } from 'react';
import './App.css'

function App() {
  const [selected, setSelected] = useState(null);
  
  const changeSelected = (imovel) => {
    setSelected(imovel);
  }

  return (
    <>
      <h1>Imobiliária Avenida</h1>
      <h2>Qual Tipo de Imóvel Você Procura?</h2>
      <hr />
      <img src="./casa.jpg" alt="" onClick={() => changeSelected("Casa")}/>
      <span>&nbsp;&nbsp;&nbsp;</span>
      <img src="./apartamento.jpg" alt="" onClick={() => changeSelected("Apartamento")}/>
      <h2>Você selecionou: <span>{selected}</span></h2>
    </>
  )
}

export default App
