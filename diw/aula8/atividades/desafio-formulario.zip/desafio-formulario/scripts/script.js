function darkMode() {
    const element = document.body;
    element.classList.toggle("dark-mode");
}
