# Operadores e Funções Matemáticas
a = 10 % 3
b = 10 / 3        # divisão com decimais
c = 10 // 3       # divisão de inteiros

print(a)
print(b)
print(c)

print(abs(10-15))

# outras funções exigem import math
import math

raiz = math.sqrt(25)
d = math.floor(12.2)
e = math.ceil(12.2)

print(raiz)
print(d)
print(e)
