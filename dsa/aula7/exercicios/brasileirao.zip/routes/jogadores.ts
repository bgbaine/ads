import { PrismaClient } from "@prisma/client"
import { Router } from "express"
import { z } from 'zod'

const prisma = new PrismaClient()

const router = Router()

const jogadorSchema = z.object({
    nome: z.string().min(4,
        { message: "Nome deve ter, no mínimo, 4 caracteres" }),
    dataNasc: z.string().refine(val => Number.isInteger(Date.parse(val)),
        {message: "Informe uma data válida no formato YYYY-MM-DD"}),
    salario: z.number().positive({ message: "Salário deve ser um número positivo" }),
    nacionalidade: z.string(),
    clubeId: z.number(),
    posicao: z.string().min(4, {
        message: "Posição deve ter, no mínimo, 4 caracteres"
    })
})

router.get("/", async (req, res) => {
    try {
        const jogadores = await prisma.jogador.findMany({
            orderBy: { id: 'desc' },
            include: { clube: true }
        })
        const jogadores2 = jogadores.map(jogador => (
            {
                ...jogador,
                idade: new Date().getFullYear() - 
                       new Date(jogador.dataNasc).getFullYear()
            }
        ))
        res.status(200).json(jogadores2)
    } catch (error) {
        res.status(500).json({ erro: error })
    }
})

router.post("/", async (req, res) => {
    const result = jogadorSchema.safeParse(req.body)

    if (!result.success) {
        res.status(400).json({ erro: result.error.issues })
        return
    }

    const { nome, dataNasc, salario, nacionalidade, clubeId, posicao } = result.data

    try {
        const jogador = await prisma.jogador.create({
            data: { nome, salario, dataNasc: new Date(dataNasc), nacionalidade, clubeId, posicao }
        })
        res.status(201).json(jogador)
    } catch (error) {
        res.status(400).json({ erro: error })
    }
})

router.put("/:id", async (req, res) => {
    // recebe o id passado como parâmetro
    const { id } = req.params

    const result = jogadorSchema.safeParse(req.body)

    if (!result.success) {
        res.status(400).json({ erro: result.error.issues })
        return
    }

    const { nome, dataNasc, salario, nacionalidade, clubeId, posicao } = result.data

    try {
        const jogador = await prisma.jogador.update({
            where: { id: Number(id) },
            data: { nome, salario, dataNasc: new Date(dataNasc), nacionalidade, clubeId, posicao }
        })
        res.status(200).json(jogador)
    } catch (error) {
        res.status(400).json({ erro: error })
    }
})

router.delete("/:id", async (req, res) => {
    // recebe o id passado como parâmetro
    const { id } = req.params

    // realiza a exclusão do jogador
    try {
        const jogador = await prisma.jogador.delete({
            where: { id: Number(id) }
        })
        res.status(200).json(jogador)
    } catch (error) {
        res.status(400).json({ erro: error })
    }
})

router.patch("/:id", async (req, res) => {
    // recebe o id passado como parâmetro
    const { id } = req.params

    const result = jogadorSchema.partial().safeParse(req.body)

    if (!result.success) {
        res.status(400).json({ erro: result.error.issues })
        return
    }

    const { salario } = result.data

    try {
        const jogador = await prisma.jogador.update({
            where: { id: Number(id) },
            data: { salario }
        })
        res.status(200).json(jogador)
    } catch (error) {
        res.status(400).json({ erro: error })
    }
})

export default router