-- AlterTable
ALTER TABLE `jogadores` ADD COLUMN `posicao` VARCHAR(20) NOT NULL DEFAULT '';
